﻿namespace UserLogin
{
    internal class LoginValidation
    {
        private string _username;
        private string _password;
        private string _errorMessage;
        public static UserRoles currentUserRole { get; private set; }

        public delegate void ActionOnError(string errorMesg);
        private ActionOnError _onError;

        public LoginValidation(string username, string password, ActionOnError onError)
        {
            _username = username;
            _password = password;
            _onError = new ActionOnError(onError);
        }

        public bool ValidateUserInput(ref User user)
        {
            bool emptyUserName;
            emptyUserName = _username.Equals(string.Empty);
            if (emptyUserName)
            {
                _errorMessage = "No username specified!";
                _onError(_errorMessage);
                currentUserRole = UserRoles.ANONYMOUS;
                return false;
            }

            bool emptyPassword;
            emptyPassword = _password.Equals(string.Empty);
            if (emptyPassword)
            {
                _errorMessage = "No password specified!";
                _onError(_errorMessage);
                currentUserRole = UserRoles.ANONYMOUS;
                return false;
            }

            bool shortUserName;
            shortUserName = _username.Length < 5;
            if (shortUserName)
            {
                _errorMessage = "Username must be at least 5 characters!";
                _onError(_errorMessage);
                currentUserRole = UserRoles.ANONYMOUS;
                return false;
            }

            bool shortPassowrd;
            shortPassowrd = _password.Length < 5;
            if (shortPassowrd)
            {
                _errorMessage = "Password must be at least 5 characters!";
                _onError(_errorMessage);
                currentUserRole = UserRoles.ANONYMOUS;
                return false;
            }

            user = UserData.IsUserPassCorrect(_username, _password);

            if (user != null)
            {
                currentUserRole = (UserRoles)user.role;
                return true;
            }
            else
            {
                _errorMessage = "No such user found!";
                _onError(_errorMessage);
                currentUserRole = UserRoles.ANONYMOUS;
                return false;
            }

            /*
             * if (user == null)
            {
                user = UserData.TestUsers[0];
            }
            else
            {
                user.username = UserData.TestUsers.username;
                user.password = UserData.TestUsers.password;
                user.facultyNumber = UserData.TestUsers.facultyNumber;
                user.role = UserData.TestUsers.role;
            }
            */
           
        }
    }
}
