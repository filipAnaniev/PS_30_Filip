﻿namespace UserLogin
{
    enum UserRoles
    {
        ANONYMOUS,
        ADMIN,
        INSPECTOR,
        PROFESSOR,
        STUDENT
    }
}