﻿namespace UserLogin
{
    internal static class UserData
    {
        static private User[] _testUsers = new User [3];
        public static User[] TestUsers
        {
            get
            {
                ResetTestUserData();
                return _testUsers;
            }
            set { }
        }

        static public User IsUserPassCorrect(string username, string password)
        {
            /*
             * for(int i=0; i<TestUsers.Length; i++)
            {
                if (username.Equals(TestUsers[i].username) && password.Equals(TestUsers[i].password))
                    return TestUsers[i];
            }
            */
            foreach(var user in TestUsers)
            {
                if(user.username.Equals(username) && password.Equals(user.password))
                        return user;
            }
            return null;
        }

        static private void ResetTestUserData()
        {
            if (_testUsers[0] == null)
            {
                _testUsers[0] = new User();
                _testUsers[0].username = "administrator";
                _testUsers[0].password = "qwerty123";
                _testUsers[0].facultyNumber = 0;
                _testUsers[0].role = 1;
            }
            if (_testUsers[1] == null)
            {
                _testUsers[1] = new User();
                _testUsers[1].username = "student1";
                _testUsers[1].password = "student1";
                _testUsers[1].facultyNumber = 3497862;
                _testUsers[1].role = 4;
            }
            if (_testUsers[2] == null)
            {
                _testUsers[2] = new User();
                _testUsers[2].username = "student2";
                _testUsers[2].password = "student2";
                _testUsers[2].facultyNumber = 3497863;
                _testUsers[2].role = 4;
            }
        }
    }
}
