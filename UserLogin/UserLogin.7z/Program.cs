﻿using System;

namespace UserLogin
{
    internal class Program
    {
        /*до 14 страница на 2ро упр; 3.1*/
        
        static void Main(string[] args)
        {
            string userName, password;
            User user1 = null;

            Console.WriteLine("Enter username: ");
            userName = Console.ReadLine();
            Console.WriteLine("Enter password: ");
            password = Console.ReadLine();

            LoginValidation validator = new LoginValidation(userName, password, ErrPrint);
            if (validator.ValidateUserInput(ref user1))
                Console.WriteLine(user1.ToString());

            switch (LoginValidation.currentUserRole)
            {
                case UserRoles.ANONYMOUS:
                    {
                        Console.WriteLine("Current user has no role or is not logged in.");
                        break;
                    }
                case UserRoles.ADMIN:
                    {
                        Console.WriteLine("Current user is admin.");
                        break;
                    }
                case UserRoles.INSPECTOR:
                    {
                        Console.WriteLine("Current user is admin.");
                        break;
                    }
                case UserRoles.PROFESSOR:
                    {
                        Console.WriteLine("Current user is professor.");
                        break;
                    }
                case UserRoles.STUDENT:
                    {
                        Console.WriteLine("Current user is student.");
                        break;
                    }
            }
        }

        static void ErrPrint(string msg)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(msg);
            Console.ResetColor();
        }

    }
}
