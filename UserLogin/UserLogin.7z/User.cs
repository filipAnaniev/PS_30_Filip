﻿namespace UserLogin
{
    internal class User
    {
        public string username { get; set; }
        public string password { get; set; }
        public int facultyNumber { get; set; }
        public int role { get; set; }

        public override string ToString()
        {
            return "Username: " + username + "\nPassword: " + password + "\nFaculty Number: " + facultyNumber + "\nRole: " + role;
        }

    }

}
